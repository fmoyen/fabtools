#!/usr/bin/ksh
#Action on SIGDANGER
/var/get_SIGDANGER
LOGFILE=/tmp/SIGDANGER.`/usr/bin/date +%d%H%M%S`.log
ESPACE="--------------------------------------------"
/usr/bin/ps aux >> $LOGFILE
echo $ESPACE >> $LOGFILE
/usr/bin/svmon -G >> $LOGFILE
echo $ESPACE >> $LOGFILE
/usr/bin/svmon -P >> $LOGFILE
echo $ESPACE >> $LOGFILE
/usr/bin/svmon -S >> $LOGFILE
echo $ESPACE >> $LOGFILE
/usr/bin/svmon -Put 10 >> $LOGFILE
echo $ESPACE >> $LOGFILE
/usr/bin/svmon -Pgt 10 >> $LOGFILE
echo $ESPACE >> $LOGFILE
/usr/opt/fabtools/bin/lsfscache >> $LOGFILE
echo $ESPACE >> $LOGFILE

/usr/sbin/sync
/usr/bin/sleep 10
