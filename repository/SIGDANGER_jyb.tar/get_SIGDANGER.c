/* Programme qui trappe le signal SIGDANGER lors de saturation   */
/* de l'espace de pagination. Specifique AIX                     */
/* get_SIGDANGER v3 8/09/2006 Jean-Yves BRUCKER                  */
/* compiler avec cc -o get_SIGDANGER -lpthread get_SIGDANGER.c   */

#include <sys/signal.h>

main() {
	sigset_t set;
	int sig;
	sigemptyset(&set);
	sigaddset(&set, SIGDANGER);
	sigaddset(&set, SIGQUIT);
	sigaddset(&set, SIGTERM);
	while (1) {
		sigwait(&set, &sig);
		switch (sig) {
			case SIGDANGER:
			exit(33); 
			case SIGQUIT:
			exit(0);
			case SIGTERM:
			exit(9);
		}
	}
}
