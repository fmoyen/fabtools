#!/usr/bin/ksh
cp action_get_SIGDANGER.sh /var/action_get_SIGDANGER.sh
cp get_SIGDANGER /var/get_SIGDANGER
chmod +x /var/get_SIGDANGER
chmod +x /var/action_get_SIGDANGER.sh
mkitab -i cons "SIGDANGER:2:respawn:/var/action_get_SIGDANGER.sh 2>&1 >/dev/null"
telinit q
