#!/usr/bin/ksh
rmitab SIGDANGER
